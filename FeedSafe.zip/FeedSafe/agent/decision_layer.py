import re

NEGATIVE_WORDS = {
    "bad", "wrong", "terrible", "awful", "horrible",
    "poor", "disappointing", "unacceptable", "useless",
    "fail", "failed", "failing", "broken"
}


def apply_decision_layer(text: str, model_pred: dict):
    """
    Decision layer:
    - Keeps model predictions by default
    - Overrides feedback_type if strong negative lexical cues exist
    """

    text_lower = text.lower()

    rule_negative = any(
        re.search(rf"\b{word}\b", text_lower)
        for word in NEGATIVE_WORDS
    )

    final_pred = model_pred.copy()
    override = False
    override_reason = "model_only"

    if rule_negative and model_pred["feedback_type"] != "negative":
        final_pred["feedback_type"] = "negative"
        override = True
        override_reason = "negative_lexical_rule"

    meta = {
        "override": override,
        "override_reason": override_reason
    }

    # ✅ EXACTLY TWO RETURNS
    return final_pred, meta
