import torch
from typing import Dict
from agent.model_loader import load_all_models
from agent.logger import log_interaction


class FeedbackAgent:
    def __init__(self):
        # Load all models once (cached by Streamlit)
        self.models, self.device = load_all_models()

    def _predict(self, text: str, tokenizer, model) -> str:
        """
        Run a single DeBERTa classifier and return the predicted label.
        """
        inputs = tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            padding=True,
            max_length=256
        ).to(self.device)

        with torch.no_grad():
            outputs = model(**inputs)
            logits = outputs.logits
            pred_id = torch.argmax(logits, dim=1).item()

        return model.config.id2label[pred_id]

    def analyze(self, text: str) -> Dict:
        """
        Analyze feedback text using the three trained models:
        - feedback category
        - feedback type
        - intent

        Also logs the interaction for research purposes.
        """

        # Load models
        fc_tokenizer, fc_model = self.models["feedback_category"]
        ft_tokenizer, ft_model = self.models["feedback_type"]
        i_tokenizer, i_model = self.models["intent"]

        # Run predictions
        result = {
            "feedback_category": self._predict(text, fc_tokenizer, fc_model),
            "feedback_type": self._predict(text, ft_tokenizer, ft_model),
            "intent": self._predict(text, i_tokenizer, i_model),
        }

        # Log interaction (raw + predicted)
        log_interaction({
            "text": text,
            "feedback_category": result["feedback_category"],
            "feedback_type": result["feedback_type"],
            "intent": result["intent"],
            "source": "streamlit_ui"
        })

        return result
