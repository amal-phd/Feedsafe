import json
from collections import defaultdict
from sklearn.metrics import accuracy_score, f1_score

INPUT_FILE = "data/benchmark/depth_benchmark_agent_outputs.jsonl"
OUT_FILE = "data/benchmark/depth_wise_metrics.json"

groups = defaultdict(list)

with open(INPUT_FILE, "r", encoding="utf-8") as f:
    for line in f:
        r = json.loads(line)
        groups[r["depth_level"]].append(r)

metrics = {}

for depth, rows in groups.items():
    metrics[depth] = {}

    for task in ["feedback_type", "feedback_category", "intent"]:
        y_true = [r[f"gold_{task}"] for r in rows]
        y_pred = [r[f"pred_{task}"] for r in rows]

        metrics[depth][task] = {
            "accuracy": accuracy_score(y_true, y_pred),
            "macro_f1": f1_score(y_true, y_pred, average="macro", zero_division=0)
        }

with open(OUT_FILE, "w", encoding="utf-8") as f:
    json.dump(metrics, f, indent=2)

print(f"✔ Depth-wise metrics saved to {OUT_FILE}")
