import json
from agent.feedback_agent import FeedbackAgent

INPUT_FILE = "data/benchmark/depth_benchmark.jsonl"
OUTPUT_FILE = "data/benchmark/depth_benchmark_agent_outputs.jsonl"

agent = FeedbackAgent()

outputs = []

with open(INPUT_FILE, "r", encoding="utf-8") as f:
    for line in f:
        row = json.loads(line)

        pred = agent.analyze(row["text"])

        outputs.append({
            **row,
            "pred_feedback_type": pred["feedback_type"],
            "pred_feedback_category": pred["feedback_category"],
            "pred_intent": pred["intent"]
        })

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    for r in outputs:
        f.write(json.dumps(r) + "\n")

print(f"✔ Agent predictions saved to {OUTPUT_FILE}")
