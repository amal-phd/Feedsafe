import json
from datetime import datetime
from pathlib import Path

LOG_FILE = Path("data/history/user_interactions.jsonl")
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

def log_interaction(record: dict):
    record["timestamp"] = datetime.utcnow().isoformat()
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
