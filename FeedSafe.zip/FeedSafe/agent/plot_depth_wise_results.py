import json
import matplotlib.pyplot as plt

# -------------------------
# CONFIG
# -------------------------
METRICS_FILE = "data/benchmark/depth_wise_metrics.json"
DEPTHS = ["shallow", "medium", "deep"]
TASKS = ["feedback_type", "feedback_category", "intent"]

TASK_LABELS = {
    "feedback_type": "Feedback Type",
    "feedback_category": "Feedback Category",
    "intent": "Intent"
}

# -------------------------
# LOAD METRICS
# -------------------------
with open(METRICS_FILE, "r", encoding="utf-8") as f:
    metrics = json.load(f)

# -------------------------
# PLOT
# -------------------------
plt.figure(figsize=(8, 5))

for task in TASKS:
    scores = [metrics[d][task]["macro_f1"] for d in DEPTHS]
    plt.plot(
        DEPTHS,
        scores,
        marker="o",
        linewidth=2,
        label=TASK_LABELS[task]
    )

    # 🔹 ADD EXACT % LABELS
    for x, y in zip(DEPTHS, scores):
        plt.text(
            x,
            y + 0.02,
            f"{y * 100:.1f}%",
            ha="center",
            va="bottom",
            fontsize=10,
            fontweight="bold"
        )

plt.ylim(0, 1.05)
plt.xlabel("Message Depth")
plt.ylabel("Macro-F1 Score")
plt.title("Model Performance vs Message Depth")
plt.grid(alpha=0.3)
plt.legend()

plt.tight_layout()
plt.savefig(
    "figures/performance_vs_depth_all_tasks_with_percentages.pdf",
    dpi=300
)
plt.show()
