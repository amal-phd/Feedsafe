import numpy as np
from datasets import load_dataset
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer
)
from sklearn.metrics import accuracy_score, f1_score
import os

# =========================
# Global configuration
# =========================
MODEL_NAME = "microsoft/deberta-v3-base"
MAX_LENGTH = 256
EPOCHS = 4
BATCH_SIZE = 8
LR = 2e-5

DATA_FILES = {
    "train": "data/splits/train.jsonl",
    "validation": "data/splits/valid.jsonl",
    "test": "data/splits/test.jsonl"
}

# =========================
# Tasks definition
# =========================
TASKS = {
    "feedback_type": {
        "labels": ["positive", "negative", "neutral"],
        "output_dir": "models/deberta_feedback_type"
    },
    "feedback_category": {
        "labels": [
            "work_evaluation",
            "revision_request",
            "task_coordination",
            "deadline_management",
            "idea_proposal",
            "clarification_request",
            "decision_assertion",
            "social_interaction",
            "others"
        ],
        "output_dir": "models/deberta_feedback_category"
    },
    "intent": {
        "labels": ["constructive", "harmful", "neutral"],
        "output_dir": "models/deberta_intent"
    }
}

CATEGORY_NORMALIZATION = {
    "other": "others"
}

# =========================
# Metrics
# =========================
def compute_metrics(p):
    preds = np.argmax(p.predictions, axis=1)
    return {
        "accuracy": accuracy_score(p.label_ids, preds),
        "macro_f1": f1_score(p.label_ids, preds, average="macro")
    }

# =========================
# Load dataset
# =========================
dataset = load_dataset("json", data_files=DATA_FILES)

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    use_fast=False
)

def tokenize(batch):
    return tokenizer(
        batch["text"],
        truncation=True,
        padding="max_length",
        max_length=MAX_LENGTH
    )

dataset = dataset.map(tokenize, batched=True)

# =========================
# Training loop
# =========================
for task_name, cfg in TASKS.items():
    print("\n" + "=" * 60)
    print(f"🚀 Training task: {task_name}")
    print("=" * 60)

    labels = cfg["labels"]
    label2id = {l: i for i, l in enumerate(labels)}
    id2label = {i: l for l, i in label2id.items()}

    def encode_labels(example):
        value = example[task_name]

        # Normalize category labels if needed
        if task_name == "feedback_category":
            value = CATEGORY_NORMALIZATION.get(value, value)

        example["label"] = label2id[value]
        return example

    task_dataset = dataset.map(encode_labels)

    task_dataset.set_format(
        type="torch",
        columns=["input_ids", "attention_mask", "label"]
    )

    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_NAME,
        num_labels=len(labels),
        label2id=label2id,
        id2label=id2label
    )

    os.makedirs(cfg["output_dir"], exist_ok=True)

    args = TrainingArguments(
        output_dir=cfg["output_dir"],
        eval_strategy="epoch",
        save_strategy="epoch",
        learning_rate=LR,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        num_train_epochs=EPOCHS,
        weight_decay=0.01,
        logging_steps=50,
        load_best_model_at_end=True,
        metric_for_best_model="macro_f1",
        report_to="none"
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=task_dataset["train"],
        eval_dataset=task_dataset["validation"],
        tokenizer=tokenizer,
        compute_metrics=compute_metrics
    )

    trainer.train()

    print("\n📊 Final test results:")
    metrics = trainer.evaluate(task_dataset["test"])
    for k, v in metrics.items():
        print(f"{k}: {v:.4f}")

    print(f"\n💾 Model saved to: {cfg['output_dir']}")

print("\n✅ All tasks trained successfully.")
