import json
import random
from pathlib import Path

INPUT = Path("data/clean_dataset_pjbl_feedback.jsonl")
OUT_DIR = Path("data/splits")

OUT_DIR.mkdir(parents=True, exist_ok=True)

with INPUT.open("r", encoding="utf-8") as f:
    data = [json.loads(line) for line in f]

random.seed(42)
random.shuffle(data)

n = len(data)
train_end = int(0.8 * n)
valid_end = int(0.9 * n)

splits = {
    "train.jsonl": data[:train_end],
    "valid.jsonl": data[train_end:valid_end],
    "test.jsonl":  data[valid_end:]
}

for name, records in splits.items():
    with (OUT_DIR / name).open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

print("JSONL split completed:")
for name, records in splits.items():
    print(f"{name}: {len(records)}")

