import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import streamlit as st
import json
import time
import re
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
from agent.feedback_agent import FeedbackAgent

# ================================================
# CONFIGURATION AND SETUP
# ================================================

st.markdown("""
<style>
/* =========================================================
EMERGENCY FIX – RESTORE LIGHT THEME + CONTROLLED DARK TOP BAR
========================================================= */

/* -------------------- RESET GLOBAL -------------------- */
.stApp, .main, body {
    background-color: #F8FAFC !important;
} /* DO NOT darken everything */
* {
    color: #0F172A !important;
}

/* -------------------- CONTENT SPACING -------------------- */
.block-container{
    max-width: 1160px !important;
    padding-top: 3.2rem !important; /* space from top bar */
    padding-bottom: 5rem !important;
    caret-color: #2563EB !important;
}

/* =========================================================
TOP BAR – DARK, FLOATING, SEPARATED
========================================================= */
header[data-testid="stHeader"]{
    background: linear-gradient(180deg, #071A2F 0%, #0B2542 100%) !important;
    box-shadow: 0 6px 18px rgba(2,6,23,0.45) !important;
    border-bottom: none !important;
}
header[data-testid="stHeader"] *{
    color: #FFFFFF !important;
}

/* Visual gap under top bar */
header[data-testid="stHeader"]::after{
    content: "";
    position: absolute;
    left: 0; right: 0; bottom: -24px;
    height: 24px;
    background: linear-gradient(
        180deg,
        rgba(2,6,23,0.25),
        transparent
    );
    pointer-events: none;
}

/* =========================================================
SIDEBAR – LIGHT AGAIN
========================================================= */
section[data-testid="stSidebar"]{
    background: #FFFFFF !important;
    border-right: 1px solid rgba(15,23,42,0.12) !important;
    box-shadow: 8px 0 22px rgba(2,6,23,0.05) !important;
}
section[data-testid="stSidebar"] *{
    color: #0F172A !important;
}

/* =========================================================
HERO BOX – BLUE, CLEAN, SEPARATED
========================================================= */
div[style*="PjBL Feedback Analysis System"]{
    margin-top: 2.6rem !important;
    background: linear-gradient(135deg, #0F3A66 0%, #1E5AA7 100%) !important;
    border-radius: 22px !important;
    padding: 2.8rem 3rem !important;
    box-shadow: 0 14px 36px rgba(2,6,23,0.18) !important;
}
div[style*="PjBL Feedback Analysis System"] h1,
div[style*="PjBL Feedback Analysis System"] p{
    color: #FFFFFF !important;
}

/* =========================================================
TABS – TWO PILLS ONLY (NO BAR)
========================================================= */
div[data-testid="stTabs"]{
    margin-top: 2.4rem !important;
}
div[data-testid="stTabs"] [role="tablist"]{
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
    padding: 0 !important;
    gap: 14px !important;
}
div[data-testid="stTabs"] [role="tab"]{
    background: #FFFFFF !important;
    border: 1px solid rgba(15,23,42,0.12) !important;
    border-radius: 999px !important;
    padding: 11px 20px !important;
    font-weight: 600 !important;
    box-shadow: 0 2px 8px rgba(2,6,23,0.08) !important;
}
div[data-testid="stTabs"] [role="tab"][aria-selected="true"]{
    background: rgba(37,99,235,0.12) !important;
    border-color: rgba(37,99,235,0.45) !important;
    font-weight: 700 !important;
}

/* =========================================================
DROPDOWN – FORCE WHITE (FIX BLACK LIST)
========================================================= */
div[data-baseweb="select"] > div{
    background: #FFFFFF !important;
    border: 1px solid rgba(15,23,42,0.22) !important;
    border-radius: 14px !important;
}
ul[role="listbox"]{
    background: #FFFFFF !important;
    border: 1px solid rgba(15,23,42,0.22) !important;
}
ul[role="listbox"] li{
    background: #FFFFFF !important;
    color: #0F172A !important;
}
ul[role="listbox"] li:hover{
    background: rgba(37,99,235,0.08) !important;
}

/* =========================================================
TEXTAREA – LIGHT + VISIBLE CURSOR
========================================================= */
textarea{
    background: #FFFFFF !important;
    border: 1.6px solid rgba(15,23,42,0.22) !important;
    border-radius: 18px !important;
    caret-color: #2563EB !important;
}
textarea::placeholder{
    color: #64748B !important;
}

/* =========================================================
BUTTONS – REMOVE BLACK BLOCKS
========================================================= */
.stButton > button[kind="primary"],
.stButton > button[kind="secondary"]{
    background: linear-gradient(180deg, #2563EB 0%, #1E40AF 100%) !important;
    color: #FFFFFF !important;
    border-radius: 999px !important;
    border: none !important;
    font-weight: 700 !important;
    box-shadow: 0 10px 24px rgba(37,99,235,0.35) !important;
}
.stButton > button[kind="primary"]:hover,
.stButton > button[kind="secondary"]:hover{
    transform: translateY(-1px);
    filter: brightness(1.05);
}

/* Star rating buttons must not look like buttons */
.stButton > button[kind="tertiary"]{
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
    padding: 0 !important;
    margin: 0 !important;
    min-height: unset !important;
    height: auto !important;
    line-height: 1 !important;
}
.stButton > button[kind="tertiary"]:hover{
    transform: none !important;
    filter: none !important;
}

/* Make tertiary button text look like a clean star icon */
.stButton > button[kind="tertiary"] p,
.stButton > button[kind="tertiary"] span,
.stButton > button[kind="tertiary"] div{
    font-size: 2.8rem !important;
    font-weight: 700 !important;
    color: #D4AF37 !important;
    text-shadow: 0 0 1px rgba(0,0,0,0.1) !important;
}

/* =========================================================
FOOTER – HIDDEN
========================================================= */
footer{
    visibility: hidden;
}

/* =========================================================
FIX: ACTIVE / HIGHLIGHTED DROPDOWN OPTION TEXT COLOR
========================================================= */
/* When an option is highlighted (keyboard / hover / active) */
ul[role="listbox"] li[aria-selected="true"],
ul[role="listbox"] li:hover,
ul[role="listbox"] li:focus {
    color: #FFFFFF !important;
}

/* In case BaseWeb applies dark background internally */
ul[role="listbox"] li[aria-selected="true"] * ,
ul[role="listbox"] li:hover * {
    color: #FFFFFF !important;
}

/* Optional: make active background slightly softer */
ul[role="listbox"] li[aria-selected="true"]{
    background-color: rgba(15,23,42,0.85) !important;
}

/* =========================================================
HARD FIX – BASEWEB SELECT ACTIVE OPTION (STREAMLIT)
========================================================= */
/* Target BaseWeb menu option root */
div[data-baseweb="menu"] [role="option"]{
    background-color: #FFFFFF !important;
    color: #0F172A !important;
}

/* Hovered option */
div[data-baseweb="menu"] [role="option"]:hover{
    background-color: rgba(37,99,235,0.12) !important;
    color: #0F172A !important;
}

/* ACTIVE / KEYBOARD-FOCUSED OPTION (this is your black row) */
div[data-baseweb="menu"] [role="option"][aria-selected="true"],
div[data-baseweb="menu"] [role="option"][data-active="true"]{
    background-color: #0F172A !important;
    color: #FFFFFF !important;
}

/* Force text inside active option to white */
div[data-baseweb="menu"] [role="option"][aria-selected="true"] *,
div[data-baseweb="menu"] [role="option"][data-active="true"] *{
    color: #FFFFFF !important;
}

/* =========================================================
ONLY FIX: Analysis Mode selected value text → WHITE
========================================================= */
/* Text inside the closed selectbox */
div[data-baseweb="select"] span{
    color: #FFFFFF !important;
    font-weight: 600 !important;
}

/* Keep arrow white too */
div[data-baseweb="select"] svg{
    fill: #FFFFFF !important;
}

/* =========================================================
FORCE ANALYSIS MODE DROPDOWN PANEL TO WHITE
========================================================= */
/* The dropdown floating panel */
div[data-baseweb="popover"]{
    background-color: #FFFFFF !important;
}

/* The menu container inside the panel */
div[data-baseweb="menu"]{
    background-color: #FFFFFF !important;
    border-radius: 14px !important;
    border: 1px solid rgba(15,23,42,0.20) !important;
    box-shadow: 0 18px 40px rgba(2,6,23,0.25) !important;
}

/* Each option row */
div[data-baseweb="menu"] [role="option"]{
    background-color: #FFFFFF !important;
    color: #0F172A !important;
    font-weight: 500 !important;
}

/* Hover */
div[data-baseweb="menu"] [role="option"]:hover{
    background-color: rgba(37,99,235,0.10) !important;
    color: #0F172A !important;
}

/* Selected option */
div[data-baseweb="menu"] [role="option"][aria-selected="true"]{
    background-color: rgba(37,99,235,0.18) !important;
    color: #0F172A !important;
}
</style>
""", unsafe_allow_html=True)

# ================================================
# AGENT INITIALIZATION
# ================================================

@st.cache_resource
def load_agent():
    return FeedbackAgent()

agent = load_agent()

# ================================================
# DATA MODELS AND ENUMS
# ================================================

class FeedbackCategory(Enum):
    WORK_EVALUATION = "work_evaluation"
    REVISION_REQUEST = "revision_request"
    TASK_COORDINATION = "task_coordination"
    DEADLINE_MANAGEMENT = "deadline_management"
    IDEA_PROPOSITION = "idea_proposition"
    CLARIFICATION_REQUEST = "clarification_request"
    DECISION_ASSERTION = "decision_assertion"
    SOCIAL_INTERACTION = "social_interaction"
    OTHER = "other"

class FeedbackType(Enum):
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"

class Intent(Enum):
    CONSTRUCTIVE = "constructive"
    NEUTRAL = "neutral"
    HARMFUL = "harmful"

@dataclass
class FeedbackAnalysis:
    text: str
    category: FeedbackCategory
    feedback_type: FeedbackType
    intent: Intent
    explanation: str

# ================================================
# UI COMPONENTS
# ================================================

def render_category_badge(category: FeedbackCategory) -> str:
    """Render a badge for feedback category."""
    labels = {
        FeedbackCategory.WORK_EVALUATION: "📊 Work Evaluation",
        FeedbackCategory.REVISION_REQUEST: "🔧 Revision Request",
        FeedbackCategory.TASK_COORDINATION: "🤝 Task Coordination",
        FeedbackCategory.DEADLINE_MANAGEMENT: "⏰ Deadline Management",
        FeedbackCategory.IDEA_PROPOSITION: "💡 Idea Proposition",
        FeedbackCategory.CLARIFICATION_REQUEST: "❓ Clarification Request",
        FeedbackCategory.DECISION_ASSERTION: "⚖️ Decision Assertion",
        FeedbackCategory.SOCIAL_INTERACTION: "👥 Social Interaction",
        FeedbackCategory.OTHER: "📝 Other"
    }
    return f'<span style="background-color: #EBF8FF; border: 1px solid #90CDF4; padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.875rem; color: #2D3748 !important;">{labels[category]}</span>'

def render_feedback_type_badge(feedback_type: FeedbackType) -> str:
    """Render a badge for feedback type."""
    labels = {
        FeedbackType.POSITIVE: "👍 Positive",
        FeedbackType.NEUTRAL: "😐 Neutral",
        FeedbackType.NEGATIVE: "👎 Negative"
    }
    colors = {
        FeedbackType.POSITIVE: "#F0FFF4; border-color: #9AE6B4",
        FeedbackType.NEUTRAL: "#EDF2F7; border-color: #CBD5E0",
        FeedbackType.NEGATIVE: "#FFF5F5; border-color: #FC8181"
    }
    return f'<span style="background-color: {colors[feedback_type].split(";")[0]}; border: 1px solid {colors[feedback_type].split(";")[1]}; padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.875rem; color: #2D3748 !important;">{labels[feedback_type]}</span>'

def render_intent_badge(intent: Intent) -> str:
    """Render a badge for intent."""
    labels = {
        Intent.CONSTRUCTIVE: "🛠️ Constructive",
        Intent.NEUTRAL: "⚪ Neutral",
        Intent.HARMFUL: "⚠️ Harmful"
    }
    return f'<span style="background-color: #F7FAFC; border: 1px solid #E2E8F0; padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.875rem; color: #2D3748 !important;">{labels[intent]}</span>'

def render_progress_bar(label: str, score: int, explanation: str, bar_type: str = "default") -> None:
    """Render a progress bar with label and explanation."""
    # Set color based on bar_type or score
    if bar_type == "conflict":
        # Red gradient for conflict
        if score >= 70:
            color = "#E53E3E"
        elif score >= 40:
            color = "#F56565"
        else:
            color = "#FED7D7"
    elif bar_type == "positive":
        # Blue gradient for positive feedback
        if score >= 70:
            color = "#3182CE"
        elif score >= 40:
            color = "#63B3ED"
        else:
            color = "#BEE3F8"
    else:
        # Default color based on score
        if score >= 70:
            color = "#38A169"
        elif score >= 40:
            color = "#D69E2E"
        else:
            color = "#E53E3E"
    
    # Special styling for conflict and positive bars
    bar_height = "14px" if bar_type in ["conflict", "positive"] else "12px"
    bar_radius = "10px" if bar_type in ["conflict", "positive"] else "8px"
    font_weight = "700" if bar_type in ["conflict", "positive"] else "600"
    
    st.markdown(f"""
    <div style="margin: 1rem 0;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <span style="font-weight: {font_weight}; color: #2D3748 !important;">{label}</span>
            <span style="font-weight: 700; color: {color};">{score}%</span>
        </div>
        <div style="background-color: #E2E8F0; border-radius: 8px; padding: 2px; height: {bar_height};">
            <div style="background-color: {color}; width: {score}%; height: {bar_height}; border-radius: {bar_radius}; transition: width 0.5s ease; box-shadow: 0 1px 3px rgba(0,0,0,0.1);"></div>
        </div>
        <div style="color: #4A5568 !important; font-size: 0.85rem; margin-top: 0.5rem; opacity: 0.9;">{explanation}</div>
    </div>
    """, unsafe_allow_html=True)

# ================================================
# MOCK LLM FUNCTION FOR SATISFACTION EVALUATION
# ================================================

def mock_llm_evaluate_satisfaction(text: str) -> Dict:
    """Mock function to evaluate feedback quality."""
    time.sleep(0.4)
    words = len(text.split())
    sentences = len(re.findall(r'[.!?]+', text))
    
    # Clarity score
    clarity = min(100, int((words / max(sentences, 1)) * 10 + 60))
    if clarity > 90:
        clarity = 90
    elif clarity < 30:
        clarity = 30
    
    # Constructiveness score
    constructive_words = len(re.findall(r'\b(could|please|consider|suggest|improve|alternative)\b', text.lower()))
    constructiveness = min(100, int((constructive_words / max(words, 1)) * 300 + 50))
    
    # Overall score
    overall = int(clarity * 0.3 + constructiveness * 0.7)
    
    # Determine feedback tone for special progress bars
    text_lower = text.lower()
    positive_words = len(re.findall(r'\b(good|excellent|great|nice|perfect|well done|appreciate|thank you)\b', text_lower))
    negative_words = len(re.findall(r'\b(wrong|bad|failed|terrible|unacceptable|awful|poor)\b', text_lower))
    
    if positive_words > negative_words:
        feedback_tone = "positive"
        tone_score = min(100, positive_words * 20 + 60)
    elif negative_words > positive_words:
        feedback_tone = "negative"
        tone_score = max(0, 100 - (negative_words * 20))
    else:
        feedback_tone = "neutral"
        tone_score = 50
    
    # Calculate conflict score based on risk words
    conflict_words = len(re.findall(r'\b(wrong|bad|failed|never|always|stupid|terrible|unacceptable)\b', text_lower))
    conflict_score = min(100, conflict_words * 25)
    
    return {
        "clarity": clarity,
        "constructiveness": constructiveness,
        "overall": overall,
        "feedback_tone": feedback_tone,
        "tone_score": tone_score,
        "conflict_score": conflict_score,
        "clarity_explanation": f"Score based on sentence complexity and readability ({'Good' if clarity > 70 else 'Needs improvement'}).",
        "constructiveness_explanation": f"{constructive_words} constructive phrases detected.",
        "overall_explanation": "Weighted average of all dimensions."
    }

# ================================================
# MAIN APPLICATION
# ================================================

def main():
    # Sidebar with white background
    with st.sidebar:
        st.markdown("<h2 style='color: #2D3748 !important; border-bottom: 2px solid #3182CE; padding-bottom: 0.5rem;'>🔧 Research Settings</h2>", unsafe_allow_html=True)
        st.selectbox(
            "Analysis Mode",
            ["Standard", "Detailed", "Experimental"],
            help="Select the depth of linguistic analysis"
        )
        st.checkbox("Enable real-time analysis", value=True)
        st.checkbox("Log anonymized data for research", value=False)
        st.checkbox("Show detailed explanations", value=True)
        
        st.markdown("---")
        st.markdown("### 📚 About")
        st.markdown("""
        <div style="margin-top: 1rem; background-color: #FFFFFF; padding: 1rem; border-radius: 8px; border: 1px solid #E2E8F0;">
            <p style="font-size: 0.85rem; color: #2D3748 !important;">
                <strong>Features:</strong><br>
                • Feedback classification<br>
                • Writing assistance<br>
                • Satisfaction metrics<br>
            </p>
            <p style="font-size: 0.8rem; color: #718096 !important; margin-top: 1rem;">
                For academic research use only.
            </p>
        </div>
        """, unsafe_allow_html=True)
    
    # Main header with blue background and white text
    st.markdown("""
    <div style="background: linear-gradient(135deg, #3182CE 0%, #2B6CB0 100%); padding: 2.5rem; border-radius: 12px; margin-bottom: 2.5rem; box-shadow: 0 4px 12px rgba(49, 130, 206, 0.15);">
        <h1 style="color: white; margin: 0; font-size: 2.8rem; font-weight: 700; letter-spacing: -0.5px;">📚 PjBL Feedback Analysis System</h1>
        <p style="color: rgba(255, 255, 255, 0.95); margin: 0.8rem 0 0 0; font-size: 1.2rem; line-height: 1.5;">
            A research prototype for analyzing and improving feedback in project-based learning environments
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Create single container for Feedback Detection
    tab1 = st.container()
    
    # Tab 1: Feedback Detection
    with tab1:
        st.markdown("<h2 style='color: #2D3748 !important; margin-bottom: 0.5rem;'>Analyze Existing Feedback</h2>", unsafe_allow_html=True)
        st.markdown("<p style='color: #4A5568 !important; margin-bottom: 1.5rem;'>Paste feedback text to analyze its characteristics and intent</p>", unsafe_allow_html=True)
        
        # Input area
        feedback_text = st.text_area(
            "Feedback Text",
            height=150,
            placeholder="Paste feedback message here...\n\nExample: 'This is completely wrong and unacceptable. Obviously you didn't even try to understand the requirements. The code is terrible and needs to be completely rewritten from scratch.'",
            key="analysis_input"
        )
        
        col1, col2, col3 = st.columns([1, 1, 2])
        with col1:
            analyze_clicked = st.button("🔍 Analyze Feedback", type="primary", use_container_width=True)
        
        if analyze_clicked and feedback_text:
            with st.spinner("Analyzing feedback characteristics..."):
                # Get analysis from the agent
                analysis_result = agent.analyze(feedback_text)
                satisfaction_result = mock_llm_evaluate_satisfaction(feedback_text)
                
                analysis = FeedbackAnalysis(
                    text=feedback_text,
                    category=FeedbackCategory(analysis_result["feedback_category"]),
                    feedback_type=FeedbackType(analysis_result["feedback_type"]),
                    intent=Intent(analysis_result["intent"]),
                    explanation=(
                        "Feedback category, type, and intent are predicted using "
                        "trained DeBERTa models. Risk and conflict indicators are "
                        "computed using rule-based heuristics."
                    )
                )
                
                # Display results in a card
                st.markdown("### 📊 Analysis Results")
                
                # Create metrics row
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.markdown("**Category**")
                    st.markdown(render_category_badge(analysis.category), unsafe_allow_html=True)
                with col2:
                    st.markdown("**Type**")
                    st.markdown(render_feedback_type_badge(analysis.feedback_type), unsafe_allow_html=True)
                with col3:
                    st.markdown("**Intent**")
                    st.markdown(render_intent_badge(analysis.intent), unsafe_allow_html=True)
                
                # Divider
                st.markdown('<hr style="border: none; height: 1px; background: linear-gradient(to right, transparent, #E2E8F0, transparent); margin: 1.5rem 0;">', unsafe_allow_html=True)
                
                # Explanation
                st.markdown(f"<p style='color: #2D3748 !important;'><strong>📝 Explanation:</strong> {analysis.explanation}</p>", unsafe_allow_html=True)
                
                # Additional insights
                st.markdown("**💡 Research Insights:**")
                if analysis.intent == Intent.CONSTRUCTIVE:
                    st.markdown("<div style='background-color: #EBF8FF; padding: 0.75rem; border-radius: 8px; border-left: 4px solid #4299E1; margin: 0.5rem 0; color: #2D3748 !important;'>- Constructive feedback correlates with 2.3x higher implementation rates</div>", unsafe_allow_html=True)
                elif analysis.intent == Intent.HARMFUL:
                    st.markdown("<div style='background-color: #FFF5F5; padding: 0.75rem; border-radius: 8px; border-left: 4px solid #FC8181; margin: 0.5rem 0; color: #2D3748 !important;'>- Harmful intent may trigger defensive reactions and reduce learning</div>", unsafe_allow_html=True)
                
                # Progress bars section
                st.markdown("### 🎯 Key Feedback Indicators")
                
                # Conflict bar in RED
                conflict_score = satisfaction_result["conflict_score"]
                conflict_explanation = f"{int(conflict_score/25)} high-conflict words detected." if conflict_score > 0 else "No high-conflict language detected."
                render_progress_bar("🚨 Conflict Level", conflict_score, conflict_explanation, bar_type="conflict")
                
                # Research-based recommendations
                st.markdown("---")
                st.markdown("**🎯 Research-Based Recommendations:**")
                if satisfaction_result["overall"] < 60:
                    st.markdown("""
                    <div style="background-color: #FFF5F5; padding: 1rem; border-radius: 8px; border-left: 4px solid #E53E3E; color: #2D3748 !important;">
                        - **Consider the SBI framework**: Situation-Behavior-Impact<br>
                        - **Balance positive and corrective feedback** (3:1 ratio recommended)<br>
                        - **Use specific examples** rather than general statements<br>
                        - **Frame as growth opportunities** rather than failures
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown("""
                    <div style="background-color: #F0FFF4; padding: 1rem; border-radius: 8px; border-left: 4px solid #38A169; color: #2D3748 !important;">
                        - ✅ Your feedback aligns well with evidence-based practices<br>
                        - Consider adding **specific action items** for even better results<br>
                        - **Timely delivery** (within 48 hours) maximizes impact<br>
                        - Regular feedback cycles improve learning outcomes by 37%
                    </div>
                    """, unsafe_allow_html=True)
                
                st.markdown("</div>", unsafe_allow_html=True)
        elif analyze_clicked and not feedback_text:
            st.warning("Please enter feedback text to analyze.")

if __name__ == "__main__":
    main()