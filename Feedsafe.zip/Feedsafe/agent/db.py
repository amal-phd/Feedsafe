# agent/db.py
import os
from pymongo import MongoClient
from pymongo.errors import PyMongoError, ConfigurationError, ServerSelectionTimeoutError

DB_NAME = "feedback_agent"
COLLECTION_NAME = "user_interactions"

MONGO_URI = os.getenv("MONGO_URI")

_local_client = None
_atlas_client = None


def get_collection():
    global _local_client, _atlas_client

    # ---- Try MongoDB Atlas first ----
    if MONGO_URI:
        try:
            if _atlas_client is None:
                print(">>> TRYING MONGODB ATLAS")
                _atlas_client = MongoClient(
                    MONGO_URI,
                    serverSelectionTimeoutMS=4000
                )
                # Force connection test
                _atlas_client.admin.command("ping")

            print(">>> USING MONGODB ATLAS")
            return _atlas_client[DB_NAME][COLLECTION_NAME]

        except (ConfigurationError, ServerSelectionTimeoutError, PyMongoError) as e:
            print(">>> ATLAS UNAVAILABLE, FALLING BACK TO LOCAL")
            print(">>> REASON:", str(e))

    # ---- Fallback: Local MongoDB ----
    if _local_client is None:
        print(">>> USING LOCAL MONGODB")
        _local_client = MongoClient("mongodb://localhost:27017")

    return _local_client[DB_NAME][COLLECTION_NAME]



