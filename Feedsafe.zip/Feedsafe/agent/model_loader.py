import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification


# =========================================================
# CONFIG — LOCAL TRAINED MODELS
# =========================================================
MODEL_PATHS = {
    "feedback_category": "models/deberta_feedback_category_synth",
    "feedback_type": "models/deberta_feedback_type_synth",
    "intent": "models/deberta_intent_synthetic",
}


# =========================================================
# DEVICE SELECTION
# =========================================================
def get_device():
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


# =========================================================
# LOAD SINGLE MODEL
# =========================================================
def load_model(model_dir: str, device):
    tokenizer = AutoTokenizer.from_pretrained(
        model_dir,
        use_fast=True
    )

    model = AutoModelForSequenceClassification.from_pretrained(
        model_dir
    )

    model.to(device)
    model.eval()

    return tokenizer, model


# =========================================================
# LOAD ALL MODELS (ONCE)
# =========================================================
def load_all_models():
    """
    Loads all trained DeBERTa models and returns:
    - dict of (tokenizer, model)
    - device
    """

    device = get_device()
    models = {}

    for task, path in MODEL_PATHS.items():
        print(f"[ModelLoader] Loading {task} from {path} on {device}")
        models[task] = load_model(path, device)

    return models, device
