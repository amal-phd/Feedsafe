import json
import os
import numpy as np
import torch
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    Trainer,
    TrainingArguments,
)
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

# ---------------------------
# CONFIG
# ---------------------------
MODEL_NAME = "microsoft/deberta-v3-base"
TRAIN_FILE = "data/final/feedback_type_synth_train.jsonl"
TEST_FILE = "data/final/feedback_type_synth_test.jsonl"
OUT_DIR = "models/deberta_feedback_type_synth"
PRED_OUT = "data/final/deberta_feedback_type_synth_predictions.jsonl"

LABELS = ["negative", "neutral", "positive"]
label2id = {l: i for i, l in enumerate(LABELS)}
id2label = {i: l for l, i in label2id.items()}

os.makedirs(OUT_DIR, exist_ok=True)

# ---------------------------
# LOAD DATA
# ---------------------------
def load_jsonl(path):
    texts, labels = [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            texts.append(r["text"])
            labels.append(label2id[r["feedback_type"]])
    return Dataset.from_dict({"text": texts, "label": labels})

train_ds = load_jsonl(TRAIN_FILE)
test_ds = load_jsonl(TEST_FILE)

# ---------------------------
# TOKENIZER & MODEL
# ---------------------------
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

def tokenize(batch):
    return tokenizer(
        batch["text"],
        truncation=True,
        padding="max_length",
        max_length=256,
    )

train_ds = train_ds.map(tokenize, batched=True)
test_ds = test_ds.map(tokenize, batched=True)

train_ds.set_format("torch", columns=["input_ids", "attention_mask", "label"])
test_ds.set_format("torch", columns=["input_ids", "attention_mask", "label"])

model = AutoModelForSequenceClassification.from_pretrained(
    MODEL_NAME,
    num_labels=len(LABELS),
    id2label=id2label,
    label2id=label2id,
)

# ---------------------------
# METRICS
# ---------------------------
def compute_metrics(pred):
    logits, labels = pred
    preds = np.argmax(logits, axis=1)

    acc = accuracy_score(labels, preds)
    p, r, f1, _ = precision_recall_fscore_support(
        labels, preds, average="macro", zero_division=0
    )

    return {
        "accuracy": acc,
        "macro_precision": p,
        "macro_recall": r,
        "macro_f1": f1,
    }

# ---------------------------
# TRAINING
# ---------------------------
args = TrainingArguments(
    output_dir=OUT_DIR,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    num_train_epochs=4,
    weight_decay=0.01,
    logging_steps=50,
    load_best_model_at_end=True,
    metric_for_best_model="macro_f1",
    report_to="none",
)

trainer = Trainer(
    model=model,
    args=args,
    train_dataset=train_ds,
    eval_dataset=test_ds,
    tokenizer=tokenizer,
    compute_metrics=compute_metrics,
)

trainer.train()
trainer.save_model(OUT_DIR)

# ---------------------------
# EXPORT PREDICTIONS
# ---------------------------
preds = trainer.predict(test_ds)
y_pred = np.argmax(preds.predictions, axis=1)
y_true = preds.label_ids

with open(PRED_OUT, "w", encoding="utf-8") as f:
    for t, p in zip(y_true, y_pred):
        f.write(json.dumps({
            "true_label": id2label[int(t)],
            "pred_label": id2label[int(p)]
        }) + "\n")

print(f"✔ Feedback TYPE model trained & saved → {OUT_DIR}")
print(f"✔ Predictions exported → {PRED_OUT}")


