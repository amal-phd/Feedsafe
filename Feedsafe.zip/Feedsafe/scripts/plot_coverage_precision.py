import json
import matplotlib.pyplot as plt
import numpy as np

METRICS_FILE = "data/final/rule_based_metrics.json"
OUTPUT_FILE = "data/final/rule_based_coverage_vs_precision.png"


def main():
    with open(METRICS_FILE, "r", encoding="utf-8") as f:
        metrics = json.load(f)

    dims = metrics["dimensions"]

    # ---- We compare Feedback Type vs Intent (as in your example)
    labels = ["Feedback", "Intent"]

    precision = [
        dims["feedback_type"]["macro"]["precision"] * 100,
        dims["intent"]["macro"]["precision"] * 100,
    ]

    coverage = [
        dims["feedback_type"]["macro"]["recall"] * 100,
        dims["intent"]["macro"]["recall"] * 100,
    ]

    x = np.arange(len(labels))
    width = 0.35

    plt.figure(figsize=(7, 4))

    bars1 = plt.bar(x - width / 2, coverage, width, label="Coverage (%)")
    bars2 = plt.bar(x + width / 2, precision, width, label="Precision (%)")

    plt.ylabel("Percentage (%)")
    plt.title("Rule-based Layer: Coverage vs Precision")
    plt.xticks(x, labels)
    plt.ylim(0, 100)
    plt.legend()

    # ---- Add value labels on bars
    for bars in [bars1, bars2]:
        for bar in bars:
            height = bar.get_height()
            plt.text(
                bar.get_x() + bar.get_width() / 2,
                height + 1,
                f"{height:.1f}%",
                ha="center",
                va="bottom",
                fontsize=9,
            )

    plt.tight_layout()
    plt.savefig(OUTPUT_FILE, dpi=300)
    plt.close()

    print(f"✔ Figure saved → {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
