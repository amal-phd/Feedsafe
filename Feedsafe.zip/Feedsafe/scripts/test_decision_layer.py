from agent.feedback_agent import FeedbackAgent
import json

agent = FeedbackAgent()

with open("data/diagnostics/decision_layer_test.jsonl") as f:
    for line in f:
        row = json.loads(line)
        raw = agent.analyze_raw(row["text"])     # model only
        final = agent.analyze(row["text"])       # with decision layer

        print({
            "text": row["text"],
            "model_prediction": raw["feedback_type"],
            "final_prediction": final["feedback_type"],
            "expected": row["expected_type"]
        })
