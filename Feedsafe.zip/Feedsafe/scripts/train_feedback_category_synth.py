import json, random, torch, numpy as np
from datasets import Dataset
from transformers import (
    AutoTokenizer, AutoModelForSequenceClassification,
    Trainer, TrainingArguments
)
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

DATA_PATH = "data/final/feedback_category_synth.jsonl"
MODEL_NAME = "microsoft/deberta-v3-base"
OUT_DIR = "models/deberta_feedback_category_synth"

SEED = 42
MAX_LEN = 256

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

rows = [json.loads(l) for l in open(DATA_PATH, encoding="utf-8")]
labels = sorted({r["label_name"] for r in rows})
label2id = {l: i for i, l in enumerate(labels)}
id2label = {i: l for l, i in label2id.items()}

random.shuffle(rows)
n = len(rows)
train, val, test = rows[:int(.8*n)], rows[int(.8*n):int(.9*n)], rows[int(.9*n):]

def to_ds(data):
    return Dataset.from_list([
        {"text": r["text"], "label": label2id[r["label_name"]]}
        for r in data
    ])

train_ds, val_ds, test_ds = map(to_ds, [train, val, test])

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

def tokenize(b):
    return tokenizer(b["text"], truncation=True, padding="max_length", max_length=MAX_LEN)

train_ds = train_ds.map(tokenize, batched=True)
val_ds   = val_ds.map(tokenize, batched=True)
test_ds  = test_ds.map(tokenize, batched=True)

for ds in [train_ds, val_ds, test_ds]:
    ds.set_format("torch", columns=["input_ids","attention_mask","label"])

model = AutoModelForSequenceClassification.from_pretrained(
    MODEL_NAME, num_labels=len(labels),
    id2label=id2label, label2id=label2id
)

def metrics(p):
    logits, y = p
    preds = np.argmax(logits, axis=1)
    p_, r_, f1_, _ = precision_recall_fscore_support(y, preds, average="macro")
    acc = accuracy_score(y, preds)
    return {"accuracy": acc, "macro_f1": f1_}

args = TrainingArguments(
    OUT_DIR,
    evaluation_strategy="epoch",
    save_strategy="no",
    num_train_epochs=4,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    learning_rate=2e-5,
    seed=SEED,
    report_to="none"
)

trainer = Trainer(
    model=model,
    args=args,
    train_dataset=train_ds,
    eval_dataset=val_ds,
    tokenizer=tokenizer,
    compute_metrics=metrics
)

trainer.train()
trainer.save_model(OUT_DIR)
tokenizer.save_pretrained(OUT_DIR)
