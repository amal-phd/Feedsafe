import json
import matplotlib.pyplot as plt

METRICS_FILE = "data/final/rule_based_metrics.json"
OUTPUT_FILE = "data/final/figure3_precision_vs_recall_scatter.png"

# Category grouping for color semantics
LEXICAL = {
    "clarification_request",
    "revision_request",
    "deadline_management",
    "work_evaluation",
}

PRAGMATIC = {
    "decision_assertion",
    "task_coordination",
    "idea_proposal",
    "social_interaction",
    "other",
}

def main():
    with open(METRICS_FILE, "r", encoding="utf-8") as f:
        metrics = json.load(f)

    cats = metrics["dimensions"]["feedback_category"]["per_label"]

    plt.figure(figsize=(7.5, 6))
    ax = plt.gca()
    ax.set_facecolor("#FAFAFA")

    for cat, m in cats.items():
        recall = m["recall"]
        precision = m["precision"]
        support = m["support"]

        # Color semantics
        if cat in LEXICAL:
            color = "#4C72B0"   # blue
        else:
            color = "#C44E52"   # red

        plt.scatter(
            recall,
            precision,
            s=40 + support * 0.15,  # size reflects frequency
            color=color,
            alpha=0.75,
            edgecolor="black",
            linewidth=0.4,
        )

        plt.text(
            recall + 0.01,
            precision + 0.01,
            cat.replace("_", "\n"),
            fontsize=8,
            ha="left",
            va="bottom",
        )

    # Diagonal reference
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray", alpha=0.4)

    plt.xlabel("Recall (Coverage)", fontsize=11)
    plt.ylabel("Precision (Reliability)", fontsize=11)
    plt.title(
        "Rule-Based Baseline: Precision vs Recall per Feedback Category",
        fontsize=13,
        pad=12,
    )

    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.grid(alpha=0.35)

    # Legend proxy
    plt.scatter([], [], color="#4C72B0", label="Lexical / Explicit")
    plt.scatter([], [], color="#C44E52", label="Pragmatic / Implicit")
    plt.legend(frameon=True)

    plt.tight_layout()
    plt.savefig(OUTPUT_FILE, dpi=300, bbox_inches="tight")
    plt.close()

    print(f"✔ Figure 3 saved → {OUTPUT_FILE}")

if __name__ == "__main__":
    main()

