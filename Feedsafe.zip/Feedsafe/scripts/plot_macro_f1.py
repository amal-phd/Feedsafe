import json
import matplotlib.pyplot as plt

METRICS_FILE = "data/final/rule_based_metrics.json"
OUTPUT_FILE = "data/final/figure1_macro_f1_ultra.png"

def main():
    with open(METRICS_FILE, "r", encoding="utf-8") as f:
        metrics = json.load(f)

    dims = metrics["dimensions"]

    # Select & order dimensions explicitly
    data = [
        ("Feedback Category", dims["feedback_category"]["macro"]["f1"], "#55A868"),
        ("Feedback Type", dims["feedback_type"]["macro"]["f1"], "#4C72B0"),
        ("Intent", dims["intent"]["macro"]["f1"], "#C44E52"),
    ]

    # Sort by performance (descending)
    data.sort(key=lambda x: x[1], reverse=True)

    labels = [d[0] for d in data]
    values = [d[1] for d in data]
    colors = [d[2] for d in data]

    plt.figure(figsize=(8.2, 4.8))
    ax = plt.gca()
    ax.set_facecolor("#FAFAFA")

    bars = plt.bar(
        labels,
        values,
        color=colors,
        edgecolor="black",
        linewidth=0.6
    )

    plt.ylabel("Macro F1-score", fontsize=11)
    plt.title(
        "Rule-Based Baseline Performance Across Core Dimensions",
        fontsize=14,
        pad=12
    )
    plt.ylim(0, 1)

    plt.grid(axis="y", linestyle="--", alpha=0.35)

    # Annotate bars
    for bar, val in zip(bars, values):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            val + 0.03,
            f"{val:.2f}",
            ha="center",
            va="bottom",
            fontsize=11,
            fontweight="bold"
        )

    # Subtle explanatory footer
    plt.figtext(
        0.5,
        -0.05,
        "Higher values indicate better balanced performance across labels (macro-averaged)",
        ha="center",
        fontsize=9,
        color="gray"
    )

    plt.tight_layout()
    plt.savefig(OUTPUT_FILE, dpi=300, bbox_inches="tight")
    plt.close()

    print(f"✔ Ultra Figure 1 saved → {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
