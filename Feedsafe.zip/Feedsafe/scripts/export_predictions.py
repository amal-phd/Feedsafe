import json, torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

MODEL_DIR = "models/deberta_feedback_category_synth"
DATA = "data/final/feedback_category_synth.jsonl"
OUT = "data/final/deberta_category_synthetic_predictions.jsonl"

tok = AutoTokenizer.from_pretrained(MODEL_DIR)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_DIR)

with open(DATA, encoding="utf-8") as f, open(OUT, "w", encoding="utf-8") as o:
    for l in f:
        r = json.loads(l)
        inputs = tok(r["text"], return_tensors="pt", truncation=True)
        pred = torch.argmax(model(**inputs).logits, dim=1).item()
        o.write(json.dumps({
            "text": r["text"],
            "true_label": r["label_name"],
            "pred_label": model.config.id2label[pred]
        }) + "\n")
